
Different classes to send and receive audio over the wire 